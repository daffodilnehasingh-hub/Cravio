const express = require("express");
const { register, login, verifyEmail, resendEmailOtp, requestPasswordReset, resetPassword, me, updateMe } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/register", register);
router.post("/login", login);
router.post("/verify-email", verifyEmail);
router.post("/resend-verification", resendEmailOtp);
router.post("/request-password-reset", requestPasswordReset);
router.post("/reset-password", resetPassword);
router.get("/me", protect, me);
router.patch("/me", protect, updateMe);

module.exports = router;