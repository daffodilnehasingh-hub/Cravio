const API="http://localhost:5000/api",outletId=new URLSearchParams(location.search).get("outletId");
const title=document.getElementById("outletName"),summary=document.getElementById("reviewSummary"),list=document.getElementById("reviewList");
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function load(){if(!outletId){list.textContent="Outlet ID is missing.";return;}try{const r=await fetch(`${API}/reviews/outlet/${encodeURIComponent(outletId)}`);const d=await r.json();if(!r.ok)throw Error(d.message||"Could not load reviews.");
title.textContent=`${d.outlet.name} reviews`;summary.className="review-summary";summary.textContent=d.reviewCount?`★ ${Number(d.averageRating).toFixed(1)} / 5 · ${d.reviewCount} review(s)`:"No reviews yet — be the first to share your experience.";
list.innerHTML=d.reviews.length?d.reviews.map(x=>`<article class="review-item"><strong>${"★".repeat(x.rating)}${"☆".repeat(5-x.rating)}</strong><p>${esc(x.comment||"No written comment.")}</p><small>${esc(x.customer?.name||"Cravio customer")} · ${new Date(x.createdAt).toLocaleDateString("en-IN")}</small></article>`).join(""):"<p>Reviews will appear here after customers complete their orders.</p>";
}catch(e){list.textContent=e.message;}}
load();
