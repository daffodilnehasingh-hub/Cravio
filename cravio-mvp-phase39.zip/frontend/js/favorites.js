const API="http://localhost:5000/api",token=localStorage.getItem("cravio-token");
const list=document.getElementById("favoriteList"),message=document.getElementById("favoriteMessage");
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function load(){if(!token){location.replace("login.html");return;}try{const r=await fetch(`${API}/favorites`,{headers:{Authorization:`Bearer ${token}`}});const d=await r.json();if(!r.ok)throw Error(d.message||"Unable to load favorites.");
list.innerHTML=d.favorites.length?d.favorites.map(o=>`<article class="favorite-outlet"><div><h2>${esc(o.name)}</h2><p>${esc(o.type)} · ${o.delivery?"Delivery available":"Pickup only"}</p><a href="menu.html?outlet=${encodeURIComponent(o.outletId)}">View menu →</a></div><button data-remove="${esc(o.outletId)}">Remove</button></article>`).join(""):"<p>You have not saved any outlets yet. Explore restaurants and canteens to add favorites.</p>";
list.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>remove(b.dataset.remove));
}catch(e){list.textContent=e.message;}}
async function remove(id){try{const r=await fetch(`${API}/favorites/${encodeURIComponent(id)}`,{method:"DELETE",headers:{Authorization:`Bearer ${token}`}});const d=await r.json();if(!r.ok)throw Error(d.message);message.textContent=d.message;load();}catch(e){message.textContent=e.message;}}
load();
